import React from "react";
import LaKarta from "./components/Karta";

export default function LaK() {
  return (
    <div>
      <h1>Bienvenido a La K</h1>
      <LaKarta />
    </div>
  );
}
