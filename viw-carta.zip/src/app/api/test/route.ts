import { NextResponse } from "next/server";
import { revalidateTag } from "next/cache";

export async function POST(req: Request) {
  try {
    console.log("Received request to revalidate menu");

    // Permite leer secret desde body o query
    let secret: string | null = null;
    const url = new URL(req.url);
    const querySecret = url.searchParams.get("secret");

    if (querySecret) {
      secret = querySecret;
    } else {
      const body = await req.json().catch(() => ({}));
      secret = body.secret;
    }

    if (secret !== process.env.REVALIDATE_SECRET) {
      return NextResponse.json(
        { revalidated: false, message: "Unauthorized" },
        { status: 401 }
      );
    }

    revalidateTag("menu");
    console.log("Se revalidó la caché del menú");
    return NextResponse.json({ revalidated: true, now: Date.now() });
  } catch (err) {
    console.error("Error revalidating menu:", err);
    return NextResponse.json(
      { revalidated: false, error: err },
      { status: 500 }
    );
  }
}
