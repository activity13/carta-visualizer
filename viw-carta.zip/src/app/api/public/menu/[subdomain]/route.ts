import { NextResponse } from "next/server";
import { connectToDatabase } from "@/lib/mongodb";

import Restaurant from "@/models/restaurants";
import CategorySchema from "@/models/categories";
import MealSchema from "@/models/meals";

// Revalidar cada 60 segundos (puedes ajustarlo a 120, 300, etc.)
export const revalidate = 60;
export const fetchCache = "force-cache";
export const dynamic = "force-static";

export async function GET(
  req: Request,
  { params }: { params: { subdomain: string } }
) {
  try {
    await connectToDatabase();
    const { subdomain } = params;

    // 1. Buscar restaurante
    const restaurant = await Restaurant.findOne({ slug: subdomain });
    if (!restaurant) {
      return NextResponse.json(
        { error: "Restaurante no encontrado" },
        { status: 404 }
      );
    }

    // 2. Buscar categorías del restaurante
    const categories = await CategorySchema.find({
      restaurantId: restaurant._id,
      isActive: true,
    });

    // 3. Buscar platos del restaurante
    const meals = await MealSchema.find({
      restaurantId: restaurant._id,
      "display.showInMenu": true,
    });

    // 4. Agrupar platos en sus categorías
    const categoriesWithMeals = categories.map((cat) => {
      const catMeals = meals.filter(
        (meal) => meal.categoryId.toString() === cat._id.toString()
      );
      return {
        id: cat._id,
        name: cat.name,
        slug: cat.slug,
        description: cat.description,
        meals: catMeals.map((m) => ({
          id: m._id,
          name: m.name,
          description: m.shortDescription || m.description,
          price: m.basePrice,
          comparePrice: m.comparePrice,
          images: m.images,
          tags: m.dietaryTags,
          featured: m.display.isFeatured,
        })),
      };
    });

    // 5. Respuesta final
    return NextResponse.json(
      {
        restaurant: {
          id: restaurant._id,
          name: restaurant.name,
          slug: restaurant.slug,
          description: restaurant.description,
          phone: restaurant.phone,
          image: restaurant.image,
        },
        categories: categoriesWithMeals,
      },
      {
        headers: { "Cache-Tag": "menu" }, // Tag de cache
        status: 200,
      }
    );
  } catch (error) {
    console.error("Error fetching menu:", error);
    return NextResponse.json(
      { error: "Error interno del servidor" },
      { status: 500 }
    );
  }
}
