import axios from "axios";

export async function revalidateMenu() {
  try {
    // Detecta el dominio automáticamente según el entorno
    console.info("🔄 Iniciando revalidación del menú...");
    const baseUrl =
      process.env.NODE_ENV === "production"
        ? process.env.NEXT_PUBLIC_API_URL
        : "http://localhost:3000";

    await axios.post(`${baseUrl}/api/test`, {
      secret: process.env.REVALIDATE_SECRET,
    });

    console.log("✅ Menú revalidado exitosamente");
  } catch (error: any) {
    console.error("❌ Error al revalidar menú:", error.message);
  }
}
