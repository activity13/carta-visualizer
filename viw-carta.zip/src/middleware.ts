import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const url = req.nextUrl.clone();
  const hostname = req.headers.get("host") || "";

  // Quitar el puerto en caso de localhost:3000
  const host = hostname.replace(/:\d+$/, ""); // ej: "app.localhost" o "mcdonalds.viwcarta.com"

  // ======================
  // 1. AMBIENTE DE PRODUCCIÓN
  // ======================
  if (host === "app.viwcarta.com") {
    if (!url.pathname.startsWith("/backoffice")) {
      url.pathname = `/backoffice${url.pathname}`;
      return NextResponse.rewrite(url);
    }
  }

  if (host.endsWith(".viwcarta.com") && host !== "app.viwcarta.com") {
    const subdomain = host.split(".")[0]; // ej: "mcdonalds"
    if (subdomain) {
      url.pathname = `/${subdomain}${url.pathname}`;
      return NextResponse.rewrite(url);
    }
  }

  // ======================
  // 2. AMBIENTE LOCAL (localhost)
  // ======================
  // Caso: app.localhost → backoffice
  if (host === "app.localhost") {
    if (!url.pathname.startsWith("/backoffice")) {
      url.pathname = `/backoffice${url.pathname}`;
      return NextResponse.rewrite(url);
    }
  }

  // Caso: restaurante.localhost → carta pública
  if (host.endsWith(".localhost") && host !== "app.localhost") {
    const subdomain = host.split(".")[0]; // ej: "mcdonalds"
    if (subdomain) {
      url.pathname = `/${subdomain}${url.pathname}`;
      return NextResponse.rewrite(url);
    }
  }

  // ======================
  // 3. DOMINIO PRINCIPAL O ROOT (landing)
  // ======================
  return NextResponse.next();
}
export const config = {
  matcher: ["/", "/dashboard/:path*", "/register", "/master/:path*"],
};
