This app help restaurants to have dominion over his gastronomic offer.

- Auth mongo/next
- Shadcn
